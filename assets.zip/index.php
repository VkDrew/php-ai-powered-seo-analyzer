<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/lib/EnvLoader.php';
require_once __DIR__ . '/lib/Crawler.php';
require_once __DIR__ . '/lib/Analyzer.php';
require_once __DIR__ . '/lib/AIService.php';

$seoData = null;
$suggestion = null;
$error = null;
$url = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['url'])) {
    $url = trim($_POST['url']);
    
    try {
        // 1. Fetch & parse
        $html = Crawler::fetch($url);
        $dom = Crawler::parse($html);

        // 2. Analyze
        $seoData = Analyzer::run($dom);

        // 3. Get AI suggestion
        $ai = new AIService();
        $suggestion = $ai->getSuggestion($seoData);

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>SEO Analyzer</title>
  <meta charset="utf-8">
  <style>
    body { 
      font-family: sans-serif; 
      max-width: 700px; 
      margin: 2rem auto; 
      padding: 0 1rem;
    }
    input, button { 
      width: 100%; 
      padding: 10px; 
      margin: 5px 0; 
      box-sizing: border-box;
    }
    button { 
      background: #0d6efd; 
      color: white; 
      border: none; 
      cursor: pointer; 
      font-size: 16px;
    }
    button:hover {
      background: #0b5ed7;
    }
    .result-section {
      margin-top: 2rem;
      padding-top: 2rem;
      border-top: 2px solid #ddd;
    }
    .error {
      color: red;
      background: #fee;
      padding: 1rem;
      border-radius: 4px;
      margin: 1rem 0;
    }
    .score {
      font-size: 2rem;
      font-weight: bold;
    }
    .score.high { color: green; }
    .score.medium { color: orange; }
    .score.low { color: red; }
    .issues {
      color: #c00;
    }
    .ai-box {
      background: #f8f9fa;
      padding: 1rem;
      border-radius: 4px;
      white-space: pre-wrap;
      overflow: auto;
    }
    .analyze-another {
      margin-top: 2rem;
      text-align: center;
    }
  </style>
</head>
<body>
  <h1>🔍 SEO Analyzer</h1>
  
  <form method="POST" action="">
    <label>Enter website URL:</label>
    <input type="url" name="url" required placeholder="https://example.com" value="<?= htmlspecialchars($url) ?>">
    <button type="submit">Analyze</button>
  </form>

  <?php if ($error): ?>
    <div class="error">
      <strong>❌ Error:</strong> <?= htmlspecialchars($error) ?>
    </div>
  <?php endif; ?>

  <?php if ($seoData): ?>
    <div class="result-section">
      <h2>✅ SEO Report</h2>
      <p><strong>URL:</strong> <?= htmlspecialchars($url) ?></p>
      <p>
        <strong>Score:</strong> 
        <span class="score <?= $seoData['score'] >= 80 ? 'high' : ($seoData['score'] >= 50 ? 'medium' : 'low') ?>">
          <?= $seoData['score'] ?>/100
        </span>
      </p>

      <h3>🚨 Issues</h3>
      <?php if (empty($seoData['issues'])): ?>
        <p>✅ No major issues found!</p>
      <?php else: ?>
        <ul class="issues">
          <?php foreach ($seoData['issues'] as $issue): ?>
            <li><?= htmlspecialchars($issue) ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <h3>🤖 AI Recommendation</h3>
      <div class="ai-box"><?= nl2br(htmlspecialchars($suggestion)) ?></div>

      <div class="analyze-another">
        <a href="index.php">← Analyze another URL</a>
      </div>
    </div>
  <?php endif; ?>

</body>
</html>